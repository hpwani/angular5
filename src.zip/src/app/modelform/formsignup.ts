export class formsignup{
  fname: string;
  lname: string;
  emailid: string;
  userpassword: string;
}
