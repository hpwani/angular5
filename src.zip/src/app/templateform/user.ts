export class User {
username: string;
gender: string;
ismarried: false;
isTCAccepted: boolean;
constructor(){

}
}
